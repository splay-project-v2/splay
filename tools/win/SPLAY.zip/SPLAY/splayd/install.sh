#!/bin/bash

#L_PATH=/cygdrive/c/SPLAY/share/lua/usr/share/lua/5.1
#L_CPATH=/cygdrive/c/SPLAY/lib/lua/usr/lib/lua/5.1
L_PATH=/cygdrive/c/SPLAY/share/lua
L_CPATH=/cygdrive/c/SPLAY/lib/lua

if [[ $L_PATH == "" ]]; then
	echo "L_PATH not set, set it (LUA_PATH)."
	exit
fi
if [[ $L_CPATH == "" ]]; then
	echo "L_CPATH not set, set it (LUA_CPATH)."
	exit
fi

echo "This script will install Splay Lua modules and Lua C modules."
echo
echo "These are only Lua modules of the Splay package, for the installation"
echo "of the other modules (that can already be installed in your system), see"
echo "INSTALL."
echo
echo "You need to have already compiled splayd. If not see INSTALL."
echo
echo "Are you ready ? (y/n)"
read ready
if [[ $ready != "y" ]]; then
	exit
fi

echo "Lua libraries will go in $L_PATH."
echo "Lua C libraries will go in $L_CPATH."
echo "Is this correct ? (y/n)"
read correct
if [[ $correct != "y" ]]; then
	echo "Aborting installation, edit this file to fix good values."
	exit
fi
echo

echo "Installing Splay Lua libraries."

mkdir -p $L_PATH
mkdir -p $L_CPATH

cp modules/json.lua  $L_PATH/

mkdir $L_PATH/splay
cp modules/splay/*.lua $L_PATH/splay
rm $L_PATH/splay/splay.lua
cp modules/*.lua $L_PATH/

mkdir $L_CPATH/splay
cp splay.dll $L_CPATH/splay_core.dll
cp luacrypto/crypto.dll $L_CPATH/crypto.dll
cp misc.dll $L_CPATH/splay/misc_core.dll
cp data_bits.dll $L_CPATH/splay/data_bits_core.dll

echo
echo

lua install_check.lua
